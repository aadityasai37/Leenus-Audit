#!/bin/sh
#aditya
cd ..
git clone --depth 1 https://github.com/CISOfy/leenus-sdk

#EOF
